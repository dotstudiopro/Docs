package com.dotstudioz.template.activities;

import android.os.Bundle;
import android.util.Log;

import com.dotstudioz.common.mobile.MobileCategoriesActivity;
import com.dotstudioz.template.R;

public class ExtendedMobileCategoriesActivity extends MobileCategoriesActivity {

    private static final String TAG = "CategoriesActivityExtended";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        setContentView(R.layout.mobile_extended_categories_activity);
        initializeApp(COMPANY_KEY);
    }

    @Override
    public void initializationSuccessful(String accessToken) {
        getData();
    }

    @Override
    public void getDataSuccess() {
        renderCategories(displaymetrics, spotLightCategoriesDTOList, findViewById(R.id.categoriesContainerExtendedLinearLayout));
    }
}
