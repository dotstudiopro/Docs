package com.dotstudioz.template.activities;

import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.dotstudioz.dotstudioPRO.dspplayer.DSPPlayerViewController;
import com.dotstudioz.template.R;

public class SimplePlayerActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_player);

        initializePlayer();
        playVideo("");
    }

    public DSPPlayerViewController getDSPPlayerViewController() {
        DSPPlayerViewController dspPlayerViewController = ((DSPPlayerViewController) getSupportFragmentManager().findFragmentById(R.id.videoPlayer));
        return dspPlayerViewController;
    }

    public void initializePlayer() {
        getDSPPlayerViewController().initializationConfiguration(getResources().getString(R.string.company_api_key),
                "advertising_id",
                DSPPlayerViewController.DEVICE_TYPE.ANDROID,
                "", "");
        getDSPPlayerViewController().usePlayerControlBar(true);
    }

    public void playVideo(String videoId) {
        getDSPPlayerViewController().playVideo(videoId);
    }


}