package com.dotstudioz.template;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.dotstudioz.common.mobile.MobileBaseActivity;
import com.dotstudioz.template.activities.ExtendedMobileCategoriesActivity;
import com.dotstudioz.template.activities.ExtendedMobileCategoryActivity;
import com.dotstudioz.template.activities.ExtendedMobileHomePageActivity;
import com.dotstudioz.template.activities.ExtendedMobilePlayerActivity;
import com.dotstudioz.template.activities.SimplePlayerActivity;

public class MainActivity extends MobileBaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mobile_activity_main);

        initializeApp(COMPANY_KEY);
    }

    public void loadHomePage(View v) {
        Intent intent = new Intent(this, ExtendedMobileHomePageActivity.class);
        startActivity(intent);
    }

    public void loadCategoriesPage(View v) {
        Intent intent = new Intent(this, ExtendedMobileCategoriesActivity.class);
        startActivity(intent);
    }

    public void loadCategoryPage(View v) {
        Intent intent = new Intent(this, ExtendedMobileCategoryActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("categorySlug", "category_slug");
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void loadSimplePlayerPage(View v) {
        Intent intent = new Intent(this, SimplePlayerActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("videoID", "video_id");
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void loadPlayerPage(View v) {
        Intent intent = new Intent(this, ExtendedMobilePlayerActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("videoID", "video_id");
        intent.putExtras(bundle);
        startActivity(intent);
    }

}