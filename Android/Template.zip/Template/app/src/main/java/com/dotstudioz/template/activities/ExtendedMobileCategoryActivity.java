package com.dotstudioz.template.activities;

import android.os.Bundle;
import android.widget.LinearLayout;

import com.dotstudioz.common.mobile.MobileCategoryActivity;
import com.dotstudioz.dotstudioPRO.models.dto.SpotLightCategoriesDTO;
import com.dotstudioz.template.R;

public class ExtendedMobileCategoryActivity extends MobileCategoryActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    String categorySlug = "";
    @Override
    public void init() {
        setContentView(R.layout.mobile_extendded_category_activity);

        initializeApp(COMPANY_KEY);

        if (getIntent() != null) {
            Bundle bundle = getIntent().getExtras();
            if (bundle != null) {
                if(bundle.containsKey("categorySlug")) {
                    categorySlug = bundle.getString("categorySlug");
                }
            }
        }
    }

    @Override
    public void initializationSuccessful(String accessToken) {
        getData(categorySlug);
    }

    @Override
    public void getChannelsForCategorySuccessful(SpotLightCategoriesDTO spotLightCategoriesDTO) {
        renderCategories(spotLightCategoriesDTO, ((LinearLayout)findViewById(R.id.channelsContainerExtendedLinearLayout)));
    }
}
