package com.dotstudioz.template.activities;

import android.os.Bundle;
import android.util.Log;

import com.dotstudioz.common.mobile.MobileHomePageActivity;
import com.dotstudioz.dotstudioPRO.models.dto.SpotLightCategoriesDTO;
import com.dotstudioz.template.R;

import java.util.ArrayList;

public class ExtendedMobileHomePageActivity extends MobileHomePageActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        setContentView(R.layout.mobile_extendded_homepage_activity);
        initializeApp(COMPANY_KEY);
    }

    @Override
    public void initializationSuccessful(String accessToken) {
        getData();
    }

    @Override
    public void getDataSuccess(ArrayList<SpotLightCategoriesDTO> spotLightCategoriesDTOArrayList) {
        loadHomePageFragment(spotLightCategoriesDTOArrayList);
    }
}