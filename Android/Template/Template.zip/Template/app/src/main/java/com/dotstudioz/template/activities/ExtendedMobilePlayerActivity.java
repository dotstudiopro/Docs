package com.dotstudioz.template.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.dotstudioz.common.ApplicationSharedController.AppController;
import com.dotstudioz.common.mobile.MobilePlayerActivity;
import com.dotstudioz.dotstudioPRO.corelibrary.constants.FontsConstants;
import com.dotstudioz.dotstudioPRO.dspplayer.DSPPlayerViewController;
import com.dotstudioz.dotstudioPRO.services.constants.ApplicationConstants;
import com.dotstudioz.template.R;

import java.net.URLEncoder;

public class ExtendedMobilePlayerActivity extends MobilePlayerActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        init();
    }

    public void init() {
        if (getIntent() != null) {
            Bundle bundle = getIntent().getExtras();
            if (bundle != null) {
                if(bundle.containsKey("videoID")) {
                    this.videoID = bundle.getString("videoID");
                }
                if(bundle.containsKey("channelSlug")) {
                    this.channelSlug = bundle.getString("channelSlug");
                }
            }
        }
        loadPlayerPage(this.videoID, this.channelSlug);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(playerActivityOpenFlag)
            finish();
    }

    String videoID;
    String channelSlug;
    private boolean playerActivityOpenFlag = false;
    public void loadPlayerPage(String videoID, String channelSlug) {
        playerActivityOpenFlag = true;
        Intent intent = new Intent(this, com.dotstudioz.common.component.player.activity.PlayerActivity.class);
        Bundle bundle = new Bundle();
        initializePlaybackOverlay(this, videoID, channelSlug);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public String APP_NAME = "APP_NAME";
    protected void initializePlaybackOverlay(Context context, String videoId, String channelslug) {
        AppController.getInstance().context = this;
        AppController.getInstance().vmapAppName = APP_NAME;
        AppController.getInstance().apikey = getResources().getString(R.string.company_api_key);
        AppController.getInstance().VMAP_APP_NAME = APP_NAME;
        AppController.getInstance().videoid = videoId;
        AppController.getInstance().channelslug = channelslug;
        AppController.getInstance().clienttoken = "";
        AppController.getInstance().deviceTypeOrdial = DSPPlayerViewController.DEVICE_TYPE.ANDROID.ordinal();
        try {
            String encodedURL = URLEncoder.encode("https://play.google.com/store/apps/details?id=playstore_package", "UTF-8");
            AppController.getInstance().ENCODED_STORE_URL = encodedURL;
        } catch(Exception e) { e.printStackTrace(); }
        AppController.getInstance().SHARING_DOMAIN_NAME = "https://company_domain.com/";
        AppController.getInstance().POST_SHARING_DOMAIN_NAME = "channel/";
        AppController.getInstance().POST_SHARING_VIDEO_DOMAIN_NAME = "";

        AppController.getInstance().themeColor = "#1E75BC";
        AppController.getInstance().isThemeColorSetFlag = true;

        AppController.getInstance().themeActiveColor = "#1E75BC";
        AppController.getInstance().isThemeActiveColorSetFlag = true;
        AppController.getInstance().themeActiveTextColor = "#000000";
        AppController.getInstance().isThemeActiveTextColorSetFlag = true;
        AppController.getInstance().themeNonActiveColor = "#ffffff";
        AppController.getInstance().isThemeNonActiveColorSetFlag = true;
        AppController.getInstance().themeNonActiveTextColor = "#5A6072";
        AppController.getInstance().isThemeNonActiveTextColorSetFlag = true;

        AppController.getInstance().idfa = "ADVERTISING_ID_CLIENT";
        AppController.getInstance().COUNTRY = COUNTRY_BASE;
        AppController.getInstance().COUNTRY_CODE = COUNTRY_BASE;
        AppController.getInstance().ISO_CODE = ISO_CODE_BASE;
        AppController.getInstance().ISO_CODE_VALUE = ISO_CODE_BASE;
        AppController.getInstance().longitudeFloat = longitudeFloat_BASE;
        AppController.getInstance().lonValue = longitudeFloat_BASE;
        AppController.getInstance().latitudeFloat = latitudeFloat_BASE;
        AppController.getInstance().latValue = latitudeFloat_BASE;

        AppController.getInstance().parentContainerColor = Color.parseColor("#ffffff");
        AppController.getInstance().titleAndDescriptionBGColor = Color.parseColor("#ffffff");
        AppController.getInstance().shareButtonColor = Color.parseColor("#000000");
        AppController.getInstance().videoTitleColor = Color.parseColor("#000000");
        FontsConstants.initializeInstance(this);
        AppController.getInstance().videoTitleFont = FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().videoTitleFontSize = 19;
        AppController.getInstance().seriesTitleColor = Color.parseColor("#5A6072");
        AppController.getInstance().seriesTitleFont = FontsConstants.robotRegularFont;
        AppController.getInstance().seriesTitleFontSize = 13;
        AppController.getInstance().videoDescriptionColor = Color.parseColor("#5A6072");
        AppController.getInstance().videoDescriptionFont = FontsConstants.robotRegularFont;
        AppController.getInstance().videoDescriptionFontSize = 13;
        AppController.getInstance().yearRatingLanguageColor = Color.parseColor("#5A6072");
        AppController.getInstance().yearRatingLanguageFont = FontsConstants.robotRegularFont;
        AppController.getInstance().yearRatingLanguageFontSize = 15;
        AppController.getInstance().companyNameColor = Color.parseColor("#5A6072");
        AppController.getInstance().companyNameFont = FontsConstants.robotRegularFont;
        AppController.getInstance().companyNameFontSize = 13;
        AppController.getInstance().castingColor = Color.parseColor("#000000");
        AppController.getInstance().castingFont = FontsConstants.robotRegularFont;
        AppController.getInstance().castingFontSize = 13;
        AppController.getInstance().writterDirectorColor = Color.parseColor("#000000");
        AppController.getInstance().writterDirectorFont = FontsConstants.robotRegularFont;
        AppController.getInstance().writterDirectorFontSize = 13;

        AppController.getInstance().childChannelTextColor = Color.parseColor("#000000");
        AppController.getInstance().childChannelFont = FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().childChannelActiveTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().childChannelActiveTextBackgroundDrawable = getResources().getDrawable(R.drawable.season_button_active);
        AppController.getInstance().childChannelNonActiveTextColor = Color.parseColor("#000000");
        AppController.getInstance().childChannelNonActiveTextBackgroundDrawable = getResources().getDrawable(R.drawable.season_button_in_active);

        AppController.getInstance().moreEpisodesText = "See More";
        AppController.getInstance().moreEpisodesTextColor = Color.parseColor("#000000");
        AppController.getInstance().moreEpisodesFont = FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().moreEpisodesTextSize = 17;
        AppController.getInstance().moreEpisodesCollapseButtonColor = Color.BLACK;

        AppController.getInstance().subscriptionOverlayOnPlayerEnabled = true;


        AppController.getInstance().playlistTypeOrdial = 1;
        AppController.getInstance().seasonItemListViewDividerColor = Color.parseColor("#AAAAAA");
        AppController.getInstance().seasonItemListViewDividerColorDividerHeight = 2;
        AppController.getInstance().seasonItemListViewActiveColor = "#1E75BC";
        AppController.getInstance().seasonItemListViewNonActiveColor = "#000000";
        AppController.getInstance().seasonItemListViewCustomFontForVideoTitle = FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().seasonItemListViewCustomFontEnabledForVideoTitle = true;
        AppController.getInstance().seasonItemListViewCustomFontForVideoDescription = FontsConstants.robotRegularFont;
        AppController.getInstance().seasonItemListViewCustomFontEnabledForVideoDescription = true;
        AppController.getInstance().playlistBackground = Color.parseColor("#ffffff");
        AppController.getInstance().seasonItemListViewShowThumbnail = true;


        AppController.getInstance().recommendationTypeOrdial = 0;
        AppController.getInstance().recommendationHeaderText = "You May Also Like";
        AppController.getInstance().recommendationHeaderTextFont = FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().recommendationHeaderTextColor = Color.parseColor("#000000");
        AppController.getInstance().recommendationLinearLayoutBackgroundColor = Color.parseColor("#ffffff");
        AppController.getInstance().recommendedVideoTitleTextColor = Color.parseColor("#000000");
        AppController.getInstance().recommendedVideoTitleFont =  FontsConstants.robotoBlackItalicFont;
        AppController.getInstance().recommendedVideoSeriesTitleTextColor = Color.parseColor("#000000");
        AppController.getInstance().recommendationHeaderTextSize = 17;


        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((Activity)context).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);

        AppController.getInstance().recommendationImageWidth = (int) (displaymetrics.widthPixels / 2);
        AppController.getInstance().recommendationImageHeight = (((displaymetrics.widthPixels / 2) * 9) / 16);
        AppController.getInstance().recommendationChannelImageWidth = (int) (displaymetrics.widthPixels / 2);
        AppController.getInstance().recommendationChannelImageHeight = (((displaymetrics.widthPixels / 2) * 9) / 16);

        ApplicationConstants.TEXT_INPUT_HEIGHT = 100;



        AppController.getInstance().trailerTitleTextViewColor = Color.parseColor("#ffffff");
        AppController.getInstance().trailerTitleTextViewFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerDescTextViewFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerPlybackButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerVideoButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerSubscribeButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerCancelButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().trailerPlybackButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().trailerVideoButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().trailerSubscribeButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().trailerCancelButtonBackgroundColor = Color.parseColor("#000000");


        AppController.getInstance().resumePlaybacbkContainerBackgroundColor = Color.parseColor("#000000");
        AppController.getInstance().resumePlaybackDescFont = FontsConstants.robotRegularFont;
        AppController.getInstance().isResumePlaybackDescFontSetFlag = true;
        AppController.getInstance().resumePlaybackButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().isRestartPlaybackButtonFontSetFlag = true;
        AppController.getInstance().resumePlaybackButtonBackgroundColor = Color.parseColor("#3366cc");
        AppController.getInstance().restartPlaybackButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().isRestartPlaybackButtonFontSetFlag = true;
        AppController.getInstance().restartPlaybackButtonBackgroundColor = Color.parseColor("#33a36d");
        AppController.getInstance().cancelPlaybackButtonFont = FontsConstants.robotRegularFont;
        AppController.getInstance().isCancelPlaybackButtonFontSetFlag = true;
        AppController.getInstance().cancelPlaybackButtonBackgroundColor = Color.parseColor("#000000");
        AppController.getInstance().visitWebsiteToPurchaseText = "Visit company_domain.com to purchase this title!";


        AppController.getInstance().resumePlaybackDescColor = Color.parseColor("#ffffff");
        AppController.getInstance().resumePlaybackDescColorSet = true;
        AppController.getInstance().resumePlaybackButtonColor = Color.parseColor("#ffffff");
        AppController.getInstance().resumePlaybackButtonTextColorSet = true;
        AppController.getInstance().resumePlaybackButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().restartPlaybackButtonColor = Color.parseColor("#ffffff");
        AppController.getInstance().restartPlaybackButtonTextColorSet = true;
        AppController.getInstance().restartPlaybackButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().cancelPlaybackButtonColor = Color.parseColor("#ffffff");
        AppController.getInstance().cancelPlaybackButtonTextColorSet = true;
        AppController.getInstance().cancelPlaybackButtonTextColor = Color.parseColor("#ffffff");


        AppController.getInstance().subscriptionModalHeaderTitleText = "SUBSCRIPTION";
        AppController.getInstance().subscriptionModalHeaderTitleTextSet = true;
        AppController.getInstance().subscriptionModalHeaderTitleFont = FontsConstants.robotRegularFont;
        AppController.getInstance().subscriptionModalHeaderTitleFontSet = true;
        AppController.getInstance().subscriptionModalChannelTitleFont = FontsConstants.robotRegularFont;
        AppController.getInstance().subscriptionModalChannelTitleFontSet = true;
        AppController.getInstance().subscriptionModalChannelTitleColor = Color.parseColor("#F00886");
        AppController.getInstance().subscriptionModalChannelTitleColorSet = true;
        AppController.getInstance().subscriptionModalMessageFont = FontsConstants.robotRegularFont;
        AppController.getInstance().subscriptionModalMessageFontSet = true;
        AppController.getInstance().loginAndSubscribeButtonTextColorSet = true;
        AppController.getInstance().loginAndSubscribeButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().loginAndSubscribeButtonBackgroundColorSet = true;
        AppController.getInstance().loginAndSubscribeButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().subscribeButtonTextColorSet = true;
        AppController.getInstance().subscribeButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().subscribeButtonBackgroundColorSet = true;
        AppController.getInstance().subscribeButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().trailerPlaybackButtonTextColorSet = true;
        AppController.getInstance().trailerPlaybackButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().trailerPlaybackButtonBackgroundColorSet = true;
        AppController.getInstance().trailerPlaybackButtonBackgroundColor = Color.parseColor("#5BB6E5");
        AppController.getInstance().subscriptionCancelButtonTextColorSet = true;
        AppController.getInstance().subscriptionCancelButtonTextColor = Color.parseColor("#ffffff");
        AppController.getInstance().subscriptionCancelButtonBackgroundColorSet = true;
        AppController.getInstance().subscriptionCancelButtonBackgroundColor = Color.parseColor("#000000");
        AppController.getInstance().isMoreInfoImageToRight = true;

        AppController.getInstance().fullScreenVideoTitleEnabled = true;
        AppController.getInstance().fullScreenVideoTitleTextTypeface = FontsConstants.robotRegularFont;
        AppController.getInstance().fullScreenVideoTitleTextTypefaceSet = true;
        AppController.getInstance().fullScreenVideoTitleTextColor = Color.WHITE;
        AppController.getInstance().fullScreenVideoTitleTextColorSet = true;
        AppController.getInstance().fullScreenVideoTitleTextSize = 20;
        AppController.getInstance().fullScreenVideoTitleTextSizeSet = true;

        AppController.getInstance().isCustomTextEnabledForWatchNowButton = true;
        AppController.getInstance().customTextForWatchNowButton = "> Watch Now";
        AppController.getInstance().isCustomSubscribeTextEnabledForWatchNowButton = true;
        AppController.getInstance().customSubscribeTextForWatchNowButton = "Subscribe Now";
        AppController.getInstance().isCustomTextSizeEnabledForWatchNowButton = true;
        AppController.getInstance().customTextSizeForWatchNowButton = 15;
        AppController.getInstance().isCustomTextColorEnabledForWatchNowButton = true;
        AppController.getInstance().customTextColorForWatchNowButton = Color.WHITE;
        AppController.getInstance().isCustomFontEnabledForWatchNowButton = true;
        AppController.getInstance().customFontForWatchNowButton = FontsConstants.robotRegularFont;
        AppController.getInstance().isCustomBackgroundColorEnabledForWatchNowButton = true;
        AppController.getInstance().customBackgroundColorForWatchNowButton = getResources().getColor(R.color.translucent_black);
        //AppController.getInstance().customBackgroundColorForWatchNowButton = getResources().getColor(R.color.transparent);

        AppController.getInstance().isCustomTextEnabledForAddToMyListButton = true;
        AppController.getInstance().customTextForAddToMyListButton = "+ Add to My Watch List";
        AppController.getInstance().isCustomTextSizeEnabledForAddToMyListButton = true;
        AppController.getInstance().customTextSizeForAddToMyListButton = 15;
        AppController.getInstance().isCustomTextColorEnabledForAddToMyListButton = true;
        AppController.getInstance().customTextColorForAddToMyListButton = Color.WHITE;
        AppController.getInstance().isCustomFontEnabledForAddToMyListButton = true;
        AppController.getInstance().customFontForAddToMyListButton = FontsConstants.robotRegularFont;
        AppController.getInstance().isCustomBackgroundColorEnabledForAddToMyListButton = true;
        AppController.getInstance().customBackgroundColorForAddToMyListButton = getResources().getColor(R.color.translucent_black);
    }
}